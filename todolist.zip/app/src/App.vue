<template>
    <div id="app">
        <RouterView />
    </div>
</template>
