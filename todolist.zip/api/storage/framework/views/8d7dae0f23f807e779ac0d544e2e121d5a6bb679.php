<p>Olá <?php echo e($user->first_name); ?>,</p>
<p>Você requisitou a alteração de senha da sua conta <?php echo e(config('app.name')); ?>. Por favor, clique no link abaixo para redefinir a sua senha.</p>

<table role="presentation" border="0" cellpadding="0" cellspacing="0" class="btn btn-primary">
    <tbody>
    <tr>
        <td align="center">
            <table role="presentation" border="0" cellpadding="0" cellspacing="0">
                <tbody>
                <tr>
                    <td> <a href="<?php echo e($resetPasswordLink); ?>" target="_blank">REDEFINIR SENHA</a> </td>
                </tr>
                </tbody>
            </table>
        </td>
    </tr>
    </tbody>
</table>

<p>Ou, simplesmente copie e cole o link abaixo em seu navegador:</p>
<p><?php echo e($resetPasswordLink); ?></p>

<p style="font-size: 12px">Por favor, ignore este email se você não requisitou alteração de senha.</p>
<?php /**PATH /Users/tiagomatosweb/Jobs/Tiago Matos/videos/pt/Todo list/api/resources/views/emails/forgot_password.blade.php ENDPATH**/ ?>